import LcButton from './components/LcButton.vue'
import LcSwiper from './components/LcSwiper.vue'

// 放置到数组中
const components = [LcButton,LcSwiper]
export default {
    install:(app,options)=>{
        components.forEach((item)=>{
            // 通过循环一个个导入组件
            app.component(item.name,item)
        })
        
    }
}


// 1、在项目的根目录下通过npm init生成package.json文件
// 2、在官网注册npm账号：https://www.npmjs.com/
// 3、登录到官网进行邮箱验证

// 代理访问npm官网：
// 1、打开自由门
// 2、配置npm代理：npm config set proxy=http://127.0.0.1:8580
// 3、删除代理：npm config delete proxy


// 4、npm login
// 5、npm publish
// 版本号相同、@符号是私有的、不能有斜杆等特殊符号



