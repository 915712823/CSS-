<template>
<div id="swipercom">
    <div :style="{width: width,height:height}" class="swiper-container" :id="'swiperIndex'+id">
      <div class="swiper-wrapper">
          <div class="swiper-slide" v-for="(item,i) in swiperList" :key="i">
              <slot :item="item" :index="i"></slot>
        </div>
          
      </div>
      <!-- 如果需要分页器 -->
      <div class="swiper-pagination"></div>
  </div>
</div>
</template>

<script>
import 'swiper/css/swiper.css'
import Swiper from 'swiper';

export default {
    name:'LcSwiper',
    data:function(){
        return {
           id:parseInt(Math.random()*1000000),
           swiper:null
        }
    },
    props:{
        swiperList:{
            type:Array,
            default:[]
        },
        slidesPerView:{
            type:Number,
            default:1
        },
        spaceBetween:{
            type:Number,
            default:0
        },
        loop:{
            type:Boolean,
            default:false
        },
        autoplay:{
            type:Boolean,
            default:false
        },
        width:{
            type:String,
            default:"7.5rem"
        },
        height:{
            type:String,
            default:"3rem"
        }
    },


    async mounted(){
        this.instance()
    },
   async updated(){
      this.instance()
   },
   methods:{
       instance(){
           if(this.swiper){
               this.swiper.destroy(false); 
           }
           
           setTimeout(()=>{
            this.swiper = new Swiper('#swiperIndex'+this.id, {
                    slidesPerView: this.slidesPerView,
                    spaceBetween: this.spaceBetween,
                    loop:this.loop, // 循环模式选项
                    autoplay:this.autoplay,
                    // 如果需要分页器
                    pagination: {
                        el: '.swiper-pagination',
                        clickable:true,
                    },
                    on:{
                        slideChangeTransitionStart:(swiper)=>{
                            this.$emit('slideChangeTransitionStart')
                            
                        },
                        slideChangeTransitionEnd:(swiper)=>{
                            this.$emit('slideChangeTransitionEnd')
                        },
                    
                    }
            });

        },10)
       }
   }
}
</script>

<style lang="less">
#swipercom{
    width: 100%;
#swiperIndex.swiper-container{
    
    border-radius: 0.1rem;
    
    .swiper-slide img{
        width: 100%;
    }
    .swiper-pagination-bullet-active{
        background-color: orangered;
    }

}
}
</style>