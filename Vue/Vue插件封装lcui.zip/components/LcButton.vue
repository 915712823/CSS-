<template>
    <button>老陈的按钮</button>
</template>


<script>
export default {
    name:"LcButton"
}
</script>